SCINESS ロゴ（2026年10月23日）

採用内容：中太字のSCINESS、角張ったS、チャコール #303640。
マークの比率：比較案B（初期案から約15％縮小）を基準とする。

sciness-logo：横組み。
sciness-logo-white：暗い背景用の白抜き横組み。
sciness-mark：マーク単体。
sciness-mark-white：白抜きマーク単体。
sciness-icon.png：SNS・アイコン用。

PNGは背景透過、SVGは輪郭をパス化した拡大可能なデータです。
SVGの文字はアウトライン化されており、追加フォントは不要です。
縦横比を固定して拡大縮小してください。

ウェブサイト：https://www.sciness.co.jp/
